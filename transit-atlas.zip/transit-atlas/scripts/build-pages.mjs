import { cp, mkdir, readFile, realpath, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = await realpath(fileURLToPath(new URL('../', import.meta.url)));
const output = join(root, 'dist');
const input = join(root, 'public');
const original = await readFile(join(input, 'index.html'), 'utf8');
const html = original.replace(/<html\b/i, '<html data-mode="static"');
if (html === original) throw new Error('The page must declare an HTML root element.');

// Remove stale exports only from the repository's own dist directory.
try {
  if (await realpath(output) !== output) throw new Error('The dist directory must be inside the project.');
  await rm(output, { recursive: true });
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}

await cp(input, output, { recursive: true });
await mkdir(join(output, 'lib'), { recursive: true });
await cp(join(root, 'lib', 'model.mjs'), join(output, 'lib', 'model.mjs'));
await writeFile(join(output, 'index.html'), html);
console.log('Built the browser edition in dist/');
