import test from 'node:test';
import assert from 'node:assert/strict';
import { CLASSES, SAMPLES, classify, parseCsv, evaluate } from '../lib/model.mjs';

test('each built-in signal demonstrates a different learned class', () => {
  assert.deepEqual(SAMPLES.map(sample => classify(sample.points).label), [...CLASSES]);
  for (const { points } of SAMPLES) {
    const result = classify(points);
    assert.equal(result.scores.length, CLASSES.length);
    assert.ok(Math.abs(result.scores.reduce((sum, item) => sum + item.score, 0) - 1) < 1e-10);
    assert.equal(result.confidence, result.scores[0].score);
  }
});

test('CSV and direct observations agree after a phase shift, flux scaling and row reversal', () => {
  const original = SAMPLES[0].points;
  const text = '\uFEFF"phase","flux"\r\n' + original.slice().reverse()
    .map(({ phase, flux }) => '"' + (phase + 0.5) + '",' + (flux * 2000)).join('\r\n');
  const parsed = parseCsv(text);
  assert.equal(parsed[0].phase, 0);
  assert.deepEqual(classify(parsed).features, classify(original).features);
  assert.equal(classify(parsed).label, classify(original).label);
});

test('invalid CSV and JSON curves get actionable errors', () => {
  assert.throws(() => parseCsv('phase,flux\n0,\n'), /numeric/);
  assert.throws(() => parseCsv('phase,flux\n0,1\n'), /32/);
  const original = SAMPLES[0].points;
  assert.throws(() => classify(original.map(p => ({ ...p, flux: Infinity }))), /finite/);
  assert.throws(() => classify([...original, original[4]]), /distinct/);
  assert.throws(() => classify(original.map(p => ({ ...p, phase: p.phase / 2 }))), /folded/);
});

test('reported accuracy matches the diagonal of the balanced synthetic holdout', () => {
  const report = evaluate();
  const correct = report.confusionMatrix.reduce((sum, row, i) => {
    assert.equal(row.reduce((a, b) => a + b, 0), report.testCount / CLASSES.length);
    return sum + row[i];
  }, 0);
  assert.equal(report.accuracy, correct / report.testCount);
  assert.ok(report.accuracy > 0.8);
  assert.equal(report.k, 7);
});
