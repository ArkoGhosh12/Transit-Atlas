import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { createApp } from '../server/index.mjs';
import { openStore } from '../server/db.mjs';

test('a visitor can classify, persist and reopen an isolated run after restarting SQLite', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'transit-atlas-test-'));
  let store;
  let server;
  async function start() {
    store = openStore(directory);
    server = createApp(store).listen(0, '127.0.0.1');
    await once(server, 'listening');
    return 'http://127.0.0.1:' + server.address().port;
  }
  async function stop() {
    await new Promise(resolve => server.close(resolve));
    store.close();
  }
  t.after(async () => { await stop(); await rm(directory, { recursive: true, force: true }); });
  let origin = await start();
  const { samples } = await (await fetch(origin + '/api/samples')).json();
  assert.equal(samples.length, 4);
  const { points, name } = samples[0];
  const post = async (endpoint, data) => fetch(origin + endpoint, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data)
  });
  assert.equal((await (await post('/api/classify', { points })).json()).label, 'Planet transit');
  assert.equal((await post('/api/classify', { points: [] })).status, 422);
  const saved = await post('/api/runs', { name, points });
  assert.equal(saved.status, 201);
  const cookie = saved.headers.get('set-cookie').split(';')[0];
  const { run } = await saved.json();
  await stop();
  origin = await start();
  const history = await (await fetch(origin + '/api/runs', { headers: { Cookie: cookie } })).json();
  assert.deepEqual(history.runs, [run]);
  assert.deepEqual(await (await fetch(origin + '/api/runs')).json(), { runs: [] });
  assert.equal((await fetch(origin + '/database/schema.sql')).status, 404);
  assert.equal((await fetch(origin + '/lib/model.mjs')).status, 200);
});
