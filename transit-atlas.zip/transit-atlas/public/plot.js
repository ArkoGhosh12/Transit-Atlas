const SVG_NS = 'http://www.w3.org/2000/svg';

function svg(tag, attributes = {}, content) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [name, value] of Object.entries(attributes)) node.setAttribute(name, value);
  if (content !== undefined) node.textContent = content;
  return node;
}

function tidyStep(rawStep) {
  const scale = 10 ** Math.floor(Math.log10(rawStep));
  const normalized = rawStep / scale;
  return ([1, 2, 2.5, 5, 10].find(value => value >= normalized) || 10) * scale;
}

function decimal(value, digits) {
  if (Math.abs(value) >= 10000) return value.toExponential(1);
  return (Math.abs(value) < 10 ** -digits / 2 ? 0 : value).toFixed(digits);
}

function nearestIndex(points, phase) {
  let left = 0;
  let right = points.length - 1;
  while (left < right) {
    const mid = Math.floor((left + right) / 2);
    if (points[mid].phase < phase) left = mid + 1;
    else right = mid;
  }
  if (left && phase - points[left - 1].phase <= points[left].phase - phase) return left - 1;
  return left;
}

// A centered moving average summarizes the observed flux. The classifier uses
// the original measurements, separately from this display-only curve.
function movingAverage(points) {
  const radius = Math.max(1, Math.min(12, Math.round(points.length / 85)));
  return points.map(({phase}, index) => {
    const start = Math.max(0, index - radius);
    const end = Math.min(points.length, index + radius + 1);
    let mean = 0;
    for (let i = start; i < end; i++) mean += (points[i].flux - mean) / (i - start + 1);
    return {phase, flux: mean};
  });
}

export class SignalPlot {
  constructor(container) {
    this.container = container;
    this.points = [];
    this.visible = {points: true, trend: true};
    this.focusIndex = 0;
    this.frame = 0;
    this.observer = new ResizeObserver(() => this.scheduleDraw());
    this.observer.observe(container);
  }

  setData(points, name) {
    const ranked = points.map(point => point.flux).sort((a, b) => a - b);
    const middle = Math.floor(ranked.length / 2);
    const lower = ranked[Math.floor((ranked.length - 1) / 2)];
    const median = lower + (ranked[middle] - lower) / 2;
    this.points = points.map(({phase, flux}) => ({phase, flux: flux / median})).sort((a, b) => a.phase - b.phase);
    if (!this.points.length || this.points.some(point => !Number.isFinite(point.flux) || point.flux <= 0)) {
      this.points = [];
      this.showRangeMessage();
      return;
    }
    this.trend = movingAverage(this.points);
    this.focusIndex = Math.floor(this.points.length / 2);
    this.name = name;
    this.scheduleDraw();
  }

  showRangeMessage() {
    const message = document.createElement('p');
    message.className = 'source-note';
    message.textContent = 'The normalized flux range is too large to plot. Check the flux units and outliers in this signal.';
    this.container.replaceChildren(message);
  }

  toggle(key) {
    const other = key === 'points' ? 'trend' : 'points';
    if (this.visible[other] || !this.visible[key]) this.visible[key] = !this.visible[key];
    this.scheduleDraw();
    return this.visible[key];
  }

  scheduleDraw() {
    cancelAnimationFrame(this.frame);
    this.frame = requestAnimationFrame(() => this.draw());
  }

  draw() {
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (!this.points.length || width < 100 || height < 90) return;
    const compact = width < 440;
    const left = compact ? 55 : 65;
    const right = width - (compact ? 14 : 20);
    const top = 12;
    const bottom = height - 44;
    const points = this.points;
    const first = points[0].phase;
    const last = points.at(-1).phase;
    let low = Infinity;
    let high = -Infinity;
    for (const point of points) {
      low = Math.min(low, point.flux);
      high = Math.max(high, point.flux);
    }
    const padding = Math.max((high - low) * 0.07, 0.00005);
    const step = tidyStep((high - low + 2 * padding) / 5);
    const yMin = Math.floor((low - padding) / step) * step;
    const yMax = Math.ceil((high + padding) / step) * step;
    const span = yMax - yMin;
    if (!Number.isFinite(span) || span <= 0 || !Number.isFinite(step) || step <= 0) {
      this.showRangeMessage();
      return;
    }
    const yIntervals = Math.max(1, Math.min(8, Math.round(span / step)));
    const px = phase => left + (phase - first) / (last - first || 1) * (right - left);
    const py = flux => bottom - (flux - yMin) / (yMax - yMin) * (bottom - top);
    const xDigits = Math.max(2, Math.min(6, Math.ceil(-Math.log10((last - first || 1) / 4)) + 1));
    const yDigits = Math.min(8, Math.max(3, Math.ceil(-Math.log10(step)) + (String(step).includes('25') ? 1 : 0)));
    const root = svg('svg', {viewBox: `0 0 ${width} ${height}`, width: '100%', height: '100%', tabindex: '0', role: 'img',
      'aria-label': `${this.name} light curve, ${points.length} observations. Use left and right arrow keys to inspect points.`,
      style: 'display:block;overflow:visible;font:12px ui-monospace,Consolas,monospace'});
    root.append(svg('title', {}, `Normalized stellar flux by orbital phase for ${this.name}`));
    const grid = svg('g', {stroke: '#293140', 'stroke-width': 1});
    const labels = svg('g', {fill: '#a4aebd', 'font-size': compact ? '10' : '11'});
    for (let i = 0; i <= yIntervals; i++) {
      const value = yMin + (i / yIntervals) * span;
      const y = py(value);
      grid.append(svg('line', {x1: left, x2: right, y1: y, y2: y, 'stroke-dasharray': '3 4'}));
      labels.append(svg('text', {x: left - 7, y: y + 3, 'text-anchor': 'end'}, decimal(value, yDigits)));
    }
    const intervals = compact ? 4 : 6;
    for (let i = 0; i <= intervals; i++) {
      const value = first + (last - first) * i / intervals;
      const x = px(value);
      grid.append(svg('line', {x1: x, x2: x, y1: top, y2: bottom, opacity: '.6', 'stroke-dasharray': '3 5'}));
      labels.append(svg('text', {x, y: bottom + 17, 'text-anchor': i === intervals ? 'end' : i === 0 ? 'start' : 'middle'}, decimal(value, xDigits)));
    }
    labels.append(svg('text', {x: (left + right) / 2, y: height - 4, 'text-anchor': 'middle'}, 'Orbital phase'));
    labels.append(svg('text', {transform: `translate(11 ${(top + bottom) / 2}) rotate(-90)`, 'text-anchor': 'middle'}, 'Normalized flux'));
    root.append(grid, labels);
    if (this.visible.trend) {
      const path = this.trend.map(({phase, flux}, i) => `${i ? 'L' : 'M'}${px(phase).toFixed(2)},${py(flux).toFixed(2)}`).join(' ');
      root.append(svg('path', {d: path, fill: 'none', stroke: 'var(--plot-trend, #8faad9)', 'stroke-width': '1.8', 'stroke-linejoin': 'round', opacity: '.94'}));
    }
    if (this.visible.points) {
      const swatch = svg('g', {fill: 'var(--plot-point, #f0b975)', 'fill-opacity': '.93'});
      const radius = Math.max(1.05, Math.min(2.5, Math.sqrt((right - left) / points.length) + 0.65));
      for (const {phase, flux} of points) swatch.append(svg('circle', {cx: px(phase), cy: py(flux), r: radius}));
      root.append(swatch);
    }

    const cursor = svg('g', {visibility: 'hidden', 'pointer-events': 'none'});
    const marker = svg('line', {y1: top, y2: bottom, stroke: '#d4c1a9', 'stroke-dasharray': '2 3', opacity: '.65'});
    const ring = svg('circle', {r: 4, fill: '#fff1dc', stroke: '#624e38', 'stroke-width': 2});
    const hint = svg('g');
    const message = svg('text', {x: 8, y: 17, fill: '#ede7dc', 'font-size': 11});
    const box = svg('rect', {width: 162, height: 26, rx: 4, fill: '#151c28', stroke: '#4a5463'});
    hint.append(box, message);
    cursor.append(marker, ring, hint);
    root.append(cursor);
    const inspect = index => {
      this.focusIndex = index;
      const point = points[index];
      const x = px(point.phase);
      const y = py(point.flux);
      const measured = `φ ${decimal(point.phase, xDigits)} · F ${decimal(point.flux, yDigits + 1)}`;
      marker.setAttribute('x1', x);
      marker.setAttribute('x2', x);
      ring.setAttribute('cx', x);
      ring.setAttribute('cy', y);
      message.textContent = measured;
      const boxWidth = Math.max(120, measured.length * 7 + 16);
      box.setAttribute('width', boxWidth);
      hint.setAttribute('transform', `translate(${Math.max(left, Math.min(x + 9, right - boxWidth))} ${Math.max(top, Math.min(y - 33, bottom - 26))})`);
      cursor.setAttribute('visibility', 'visible');
      root.setAttribute('aria-label', `${this.name}. Phase ${decimal(point.phase, xDigits)}, normalized flux ${decimal(point.flux, yDigits + 1)}. Use arrow keys to inspect.`);
    };
    root.addEventListener('pointermove', event => {
      const rect = root.getBoundingClientRect();
      const x = (event.clientX - rect.left) * width / rect.width;
      const y = (event.clientY - rect.top) * height / rect.height;
      if (x < left || x > right || y < top || y > bottom) {
        cursor.setAttribute('visibility', 'hidden');
        return;
      }
      inspect(nearestIndex(points, first + (x - left) / (right - left) * (last - first)));
    });
    const hide = () => cursor.setAttribute('visibility', 'hidden');
    root.addEventListener('pointerleave', hide);
    root.addEventListener('blur', hide);
    root.addEventListener('focus', () => inspect(this.focusIndex));
    root.addEventListener('keydown', event => {
      const next = {ArrowLeft: this.focusIndex - 1, ArrowRight: this.focusIndex + 1, Home: 0, End: points.length - 1}[event.key];
      if (next === undefined) return;
      event.preventDefault();
      inspect(Math.max(0, Math.min(points.length - 1, next)));
    });
    this.container.replaceChildren(root);
  }
}
