import {SignalPlot} from './plot.js';

const $ = id => document.getElementById(id);
const setText = (id, value) => { if ($(id)) $(id).textContent = value; };
const selectAll = selector => Array.from(document.querySelectorAll(selector));
const percent = value => `${Number((value * 100).toFixed(1))}%`;
const storeKey = 'transit-atlas.experiments.v1';
const isStatic = document.documentElement.dataset.mode === 'static' || location.hostname.endsWith('.github.io');
const descriptions = {
  'Planet transit': 'This light curve resembles the brightness dip of a planet crossing its star.',
  'Eclipsing binary': 'This light curve resembles the dimming of stars passing in front of one another.',
  'Stellar variability': 'This light curve resembles a star whose brightness varies over its cycle.',
  Noise: 'This light curve most closely resembles the training examples with unstructured brightness fluctuations.'
};

const state = {
  mode: null, samples: [], sample: null, result: null, saved: false,
  classifying: false, saving: false, selectionId: 0, view: 'lab', model: null
};
const plot = new SignalPlot($('chart'));
let modelPromise;
function model() {
  if (!modelPromise) modelPromise = import('./lib/model.mjs').catch(error => { modelPromise = null; throw error; });
  return modelPromise;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

let dismissStatus;
function announce(text, isError = false) {
  const target = $('app-status');
  if (!target) return;
  clearTimeout(dismissStatus);
  target.textContent = text;
  target.classList.toggle('is-error', isError);
  target.hidden = !text;
  if (text && !isError) dismissStatus = setTimeout(() => announce(''), 6000);
}

class ApiError extends Error {
  constructor(text, status, unavailable = false) {
    super(text);
    this.status = status;
    this.unavailable = unavailable;
  }
}

async function api(path, body) {
  const options = {credentials: 'same-origin', headers: {Accept: 'application/json'}};
  if (body) {
    options.method = 'POST';
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }
  const response = await fetch(new URL(`api/${path}`, document.baseURI), options);
  const json = response.headers.get('content-type')?.includes('application/json');
  if (!json) {
    throw new ApiError('The signal service returned an unexpected response.', response.status,
      response.status === 404 || response.status === 405 || response.ok);
  }
  const value = await response.json();
  if (!response.ok) throw new ApiError(typeof value.error === 'string' ? value.error : 'The request could not be completed.', response.status, response.status === 404);
  return value;
}

function localRuns() {
  const stored = JSON.parse(localStorage.getItem(storeKey) || '[]');
  if (!Array.isArray(stored)) throw new Error('The saved browser log could not be read.');
  return stored;
}

async function getRuns() {
  return state.mode === 'local' ? localRuns() : (await api('runs')).runs;
}

const buttonLabels = new Map();
function buttonText(id, text) {
  const button = $(id);
  if (!button) return;
  // Keep icons in place when changing a button's visible label.
  let label = button.querySelector('[data-button-label]');
  if (!label) {
    const node = [...button.childNodes].find(child => child.nodeType === Node.TEXT_NODE && child.textContent.trim());
    if (node) {
      label = element('span', '', node.textContent.trim());
      label.dataset.buttonLabel = '';
      node.replaceWith(label);
    } else {
      label = button.querySelector('span');
    }
  }
  if (!label) return;
  if (!buttonLabels.has(id)) buttonLabels.set(id, label.textContent);
  label.textContent = text ?? buttonLabels.get(id);
}

function controls() {
  $('classify-btn').disabled = !state.sample || state.classifying || state.saving;
  $('save-btn').disabled = !state.result || state.saved || state.saving || state.classifying;
  $('classify-btn').setAttribute('aria-busy', String(state.classifying));
  $('save-btn').setAttribute('aria-busy', String(state.saving));
  buttonText('classify-btn', state.classifying ? 'Analyzing…' : null);
  buttonText('save-btn', state.saving ? 'Saving…' : state.saved ? 'Saved' : null);
}

function showResult() {
  const result = state.result;
  setText('result-label', result?.label || (state.classifying ? 'Analyzing signal' : 'Ready to classify'));
  setText('result-description', result ? descriptions[result.label] || 'Closest class among the training examples.' : 'Run the classifier to compare this signal with the model’s training examples.');
  setText('result-state', result ? 'Classified' : state.classifying ? 'Analyzing' : 'Awaiting analysis');
  setText('confidence-value', result ? percent(result.confidence) : '—');
  const bar = $('confidence-bar');
  if (bar) {
    bar.style.width = result ? percent(result.confidence) : '0%';
    bar.setAttribute('aria-valuenow', String(result ? Math.round(result.confidence * 100) : 0));
  }
  setText('transit-depth', result ? `${Number(result.features.depthPpt.toFixed(2))} ppt` : '—');
  setText('scatter-value', result ? `${Number(result.features.scatterPpt.toFixed(2))} ppt` : '—');
  if (result) setText('model-version', result.modelVersion);
  const list = $('score-list');
  if (!list) return;
  list.replaceChildren();
  if (!result) return;
  for (const {label, score} of [...result.scores].sort((a, b) => b.score - a.score)) {
    const row = element('div', `score-row${label === result.label ? ' is-top' : ''}`);
    const line = element('div', 'score-line');
    line.append(element('span', 'score-label', label), element('span', 'score-value', percent(score)));
    const track = element('div', 'score-track');
    track.setAttribute('aria-hidden', 'true');
    const fill = element('div', 'score-fill');
    fill.style.width = percent(score);
    track.append(fill);
    row.append(line, track);
    list.append(row);
  }
}

async function classifyCurrent(announceResult = true) {
  if (!state.sample || state.classifying) return;
  const selection = state.selectionId;
  state.classifying = true;
  controls();
  if (!state.result) showResult();
  try {
    const {points} = state.sample;
    const result = state.mode === 'local' ? (await model()).classify(points) : await api('classify', {points});
    if (selection !== state.selectionId) return;
    state.result = result;
    if (announceResult) announce(`Analysis complete. ${result.label}, ${percent(result.confidence)} neighbor agreement.`);
  } catch (error) {
    if (selection === state.selectionId) announce(error.message || 'The analysis failed. Try running it again.', true);
  } finally {
    if (selection === state.selectionId) {
      state.classifying = false;
      showResult();
      controls();
    }
  }
}

function selectSample(sample, {savedResult = null, saved = false} = {}) {
  state.selectionId++;
  Object.assign(state, {sample, result: savedResult, saved, classifying: false, saving: false});
  const select = $('sample-select');
  select.querySelector('[data-temporary]')?.remove();
  const known = state.samples.some(entry => entry === sample);
  if (!known) {
    const option = new Option(sample.name, 'custom');
    option.dataset.temporary = '';
    select.add(option);
  }
  select.value = known ? sample.id : 'custom';
  setText('sample-name', known ? `Simulated observation · ${sample.name}` : sample.name);
  setText('sample-description', sample.description);
  setText('point-count', sample.points.length.toLocaleString());
  setText('instrument-id', known ? sample.id : saved ? 'Saved experiment' : 'CSV import');
  plot.setData(sample.points, sample.name);
  announce('');
  showResult();
  controls();
}

async function uploadCsv(event) {
  const input = event.currentTarget;
  const file = input.files[0];
  input.value = '';
  if (!file) return;
  const selection = state.selectionId;
  try {
    if (file.size > 256 * 1024) throw new Error('Choose a CSV up to 256 KiB.');
    const shared = await model();
    const points = shared.parseCsv(await file.text());
    if (selection !== state.selectionId) return;
    const name = file.name.replace(/\.csv$/i, '').trim().slice(0, 80) || 'Imported signal';
    selectSample({id: 'custom', name, points, description: 'Imported light curve from your CSV.'});
    announce(`Loaded ${points.length.toLocaleString()} points from ${file.name}. Run the classifier to analyze them.`);
  } catch (error) {
    if (selection === state.selectionId) announce(error.message || 'This CSV could not be loaded.', true);
  }
}

function exampleCsv(event) {
  event.preventDefault();
  const sample = state.samples[0];
  if (!sample) return;
  const rows = sample.points.map(({phase, flux}) => `${phase},${flux}`);
  const blob = new Blob([['phase,flux', ...rows].join('\n') + '\n'], {type: 'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${sample.id}-example.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function saveCurrent() {
  if (!state.result || state.saving || state.saved) return;
  const selection = state.selectionId;
  const {name, points} = state.sample;
  state.saving = true;
  controls();
  try {
    if (state.mode === 'local') {
      const runs = localRuns();
      const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, '0')).join('');
      runs.unshift({id, name, points, result: state.result, createdAt: new Date().toISOString()});
      localStorage.setItem(storeKey, JSON.stringify(runs.slice(0, 30)));
    } else {
      await api('runs', {name, points});
    }
    if (selection === state.selectionId) {
      state.saved = true;
      announce(`Saved ${name} to the experiment log.`);
    }
    if (state.view === 'log') await renderLog();
  } catch (error) {
    if (selection === state.selectionId) announce(error.name === 'QuotaExceededError' ? 'Browser storage is full. This experiment could not be saved.' : error.message || 'This experiment could not be saved.', true);
  } finally {
    if (selection === state.selectionId) {
      state.saving = false;
      controls();
    }
  }
}

let logRequest = 0;
async function renderLog() {
  const current = ++logRequest;
  const panel = $('log-list');
  if (!panel || !state.mode) return;
  panel.setAttribute('aria-busy', 'true');
  try {
    const runs = await getRuns();
    if (current !== logRequest) return;
    setText('log-count', String(runs.length));
    const content = new DocumentFragment();
    if (!runs.length) {
      const empty = element('div', 'log-empty');
      empty.append(element('h3', '', 'Your experiment log is empty'), element('p', '', 'Analyze a light curve and save the result to revisit it here.'));
      const lab = element('button', 'log-open', 'Open Signal Lab');
      lab.type = 'button';
      lab.addEventListener('click', () => navigate('lab'));
      empty.append(lab);
      content.append(empty);
    }
    for (const run of [...runs].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))) {
      const row = element('div', 'log-row');
      const main = element('div', 'log-main');
      const date = new Date(run.createdAt);
      const dateString = Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat(undefined, {dateStyle: 'medium', timeStyle: 'short'}).format(date);
      main.append(element('h3', 'log-name', run.name), element('p', 'log-meta', `${dateString} · ${run.points.length.toLocaleString()} points`));
      const label = element('span', 'log-label', run.result.label);
      const open = element('button', 'log-open', 'Reopen');
      open.type = 'button';
      open.setAttribute('aria-label', `Reopen ${run.name}`);
      open.addEventListener('click', () => {
        selectSample({id: run.id, name: run.name, points: run.points, description: 'Restored from your experiment log.'}, {savedResult: run.result, saved: true});
        navigate('lab');
      });
      row.append(main, label, open);
      content.append(row);
    }
    panel.replaceChildren(content);
  } catch (error) {
    if (current === logRequest) {
      const empty = element('div', 'log-empty');
      empty.append(element('h3', '', 'Experiment log unavailable'), element('p', '', error.message));
      const retry = element('button', 'log-open', 'Try again');
      retry.type = 'button';
      retry.addEventListener('click', renderLog);
      empty.append(retry);
      panel.replaceChildren(empty);
    }
  } finally {
    if (current === logRequest) panel.removeAttribute('aria-busy');
  }
}

async function renderNotes() {
  if (!state.mode) return;
  try {
    state.model ||= state.mode === 'local' ? (await model()).evaluate() : await api('model');
    const metrics = state.model;
    setText('model-accuracy', percent(metrics.accuracy));
    setText('model-training', metrics.trainingCount.toLocaleString());
    setText('model-test', metrics.testCount.toLocaleString());
    setText('model-k', String(metrics.k));
    const matrix = $('model-matrix');
    if (matrix && Array.isArray(metrics.confusionMatrix)) {
      const table = element('table');
      const caption = element('caption', '', 'Held-out examples by actual class and model prediction');
      table.append(caption);
      const head = table.createTHead().insertRow();
      for (const label of ['Actual / predicted', ...metrics.classes]) {
        const cell = element('th', '', label);
        cell.scope = 'col';
        head.append(cell);
      }
      const body = table.createTBody();
      metrics.confusionMatrix.forEach((counts, i) => {
        const row = body.insertRow();
        const actual = element('th', '', metrics.classes[i]);
        actual.scope = 'row';
        row.append(actual);
        for (const count of counts) row.insertCell().textContent = count;
      });
      matrix.replaceChildren(table);
    }
  } catch (error) {
    if (state.view === 'notes') announce(error.message || 'Model metrics are unavailable.', true);
  }
}

function selectedView() {
  const hash = location.hash.slice(1);
  return ['lab', 'log', 'notes'].includes(hash) ? hash : 'lab';
}

function showView(view, focus = false) {
  state.view = view;
  for (const section of selectAll('[data-view]')) section.hidden = section.dataset.view !== view;
  for (const item of selectAll('[data-nav]')) {
    const active = item.dataset.nav === view;
    item.classList.toggle('is-active', active);
    if (active) item.setAttribute('aria-current', 'page');
    else item.removeAttribute('aria-current');
  }
  announce('');
  if (view === 'log') renderLog();
  if (view === 'notes') renderNotes();
  if (view === 'lab') plot.scheduleDraw();
  if (focus) {
    const heading = document.querySelector(`[data-view="${view}"] h1, [data-view="${view}"] h2`);
    if (heading) {
      heading.tabIndex = -1;
      heading.focus({preventScroll: true});
    }
    window.scrollTo({top: 0, behavior: 'instant'});
  }
}

function navigate(view) {
  if (location.hash !== `#${view}`) history.pushState(null, '', `#${view}`);
  showView(view, true);
}

for (const link of selectAll('[data-nav]')) {
  link.addEventListener('click', event => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    navigate(link.dataset.nav);
  });
}
window.addEventListener('hashchange', () => {
  if (location.hash !== '#main-content') showView(selectedView(), true);
});
$('sample-select').addEventListener('change', event => {
  const sample = state.samples.find(entry => entry.id === event.target.value);
  if (sample) selectSample(sample);
});
$('classify-btn').addEventListener('click', () => classifyCurrent());
$('save-btn').addEventListener('click', saveCurrent);
$('csv-input').addEventListener('change', uploadCsv);
$('csv-example')?.addEventListener('click', exampleCsv);
for (const toggle of selectAll('[data-series]')) {
  toggle.addEventListener('click', () => {
    toggle.setAttribute('aria-pressed', String(plot.toggle(toggle.dataset.series)));
    for (const button of selectAll('[data-series]')) {
      const key = button.dataset.series;
      button.disabled = plot.visible[key] && !plot.visible[key === 'points' ? 'trend' : 'points'];
    }
  });
}

async function initialize() {
  controls();
  showView(selectedView());
  $('sample-select').disabled = true;
  $('csv-input').disabled = true;
  try {
    if (!isStatic) {
      try {
        state.samples = (await api('samples')).samples;
        state.mode = 'server';
      } catch (error) {
        if (!(error instanceof ApiError && error.unavailable)) throw error;
      }
    }
    if (!state.mode) {
      state.samples = (await model()).SAMPLES;
      state.mode = 'local';
    }
    const local = state.mode === 'local';
    setText('system-status', local ? 'Browser demo' : 'System online');
    $('system-status').dataset.state = local ? 'local' : 'online';
    setText('storage-note', local ? 'Experiments are saved in this browser’s local storage.' : 'Saved experiments are linked to this browser by a private cookie.');
    if ($('system-status')) $('system-status').title = local ? 'Model runs on this device. Saved experiments use this browser’s local storage.' : 'Connected to the signal API and experiment database.';
    const select = $('sample-select');
    select.replaceChildren(...state.samples.map(sample => new Option(sample.name, sample.id)));
    select.disabled = false;
    $('csv-input').disabled = false;
    selectSample(state.samples[0]);
    if (state.view === 'log') renderLog();
    if (state.view === 'notes') renderNotes();
    await classifyCurrent(false);
  } catch (error) {
    setText('system-status', 'Service unavailable');
    $('system-status').dataset.state = 'offline';
    announce(`Could not load the signal lab. ${error.message} Reload to try again.`, true);
  }
}

initialize();
