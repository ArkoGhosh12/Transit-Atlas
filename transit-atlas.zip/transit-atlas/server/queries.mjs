export const listSql = `
  SELECT id, name, created_at, points_json, result_json
  FROM experiments WHERE owner_hash = ?
  ORDER BY created_at DESC, id DESC LIMIT 30`;

export const insertSql = `
  INSERT INTO experiments (id, owner_hash, name, created_at, points_json, result_json)
  VALUES (?, ?, ?, ?, ?, ?)`;

export const pruneSql = `
  DELETE FROM experiments WHERE owner_hash = ? AND id IN (
    SELECT id FROM experiments WHERE owner_hash = ?
    ORDER BY created_at DESC, id DESC LIMIT -1 OFFSET 30
  )`;

export function parameters(owner, run) {
  return [run.id, owner, run.name, run.createdAt, JSON.stringify(run.points), JSON.stringify(run.result)];
}

export function fromRow(row) {
  return {
    id: row.id, name: row.name, createdAt: row.created_at,
    points: JSON.parse(row.points_json), result: JSON.parse(row.result_json)
  };
}
