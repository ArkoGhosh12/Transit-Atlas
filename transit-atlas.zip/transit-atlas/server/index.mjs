import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleApi } from './api.mjs';
import { openStore } from './db.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const publicDir = path.join(root, 'public');
const types = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.webp': 'image/webp', '.png': 'image/png',
  '.csv': 'text/csv; charset=utf-8', '.woff2': 'font/woff2', '.ico': 'image/x-icon'
};

function assetPath(pathname) {
  if (pathname === '/lib/model.mjs') return path.join(root, 'lib', 'model.mjs');
  const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
  if (!relative || relative.split('/').some(part => !/^[a-zA-Z0-9_-][a-zA-Z0-9._-]*$/.test(part))) return null;
  return path.join(publicDir, relative);
}

export function createApp(store) {
  return http.createServer(async (req, res) => {
    try {
      const proto = req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https' ? 'https:' : 'http:';
      const base = process.env.PUBLIC_ORIGIN || proto + '//' + (req.headers.host || 'localhost');
      const url = new URL(req.url, base);
      if (url.origin !== new URL(base).origin) { res.writeHead(400).end(); return; }
      if (url.pathname.startsWith('/api/')) {
        const init = { method: req.method, headers: req.headers };
        if (req.method !== 'GET' && req.method !== 'HEAD') Object.assign(init, { body: req, duplex: 'half' });
        const response = await handleApi(new Request(url, init), store);
        res.writeHead(response.status, Object.fromEntries(response.headers));
        res.end(Buffer.from(await response.arrayBuffer()));
        return;
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return; }
      const file = assetPath(url.pathname);
      if (!file || !types[path.extname(file)]) { res.writeHead(404).end('File not found.'); return; }
      const body = await readFile(file);
      res.writeHead(200, {
        'Content-Type': types[path.extname(file)], 'Content-Length': body.byteLength,
        'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin',
        'Cache-Control': 'no-cache'
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch (error) {
      const missing = error.code === 'ENOENT' || error.code === 'EISDIR';
      res.writeHead(missing ? 404 : 400).end(missing ? 'File not found.' : 'Could not process this request.');
    }
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const store = openStore(process.env.DATA_DIR || path.join(root, 'data'));
  const host = process.env.HOST || '127.0.0.1';
  const port = Number(process.env.PORT || 3000);
  const server = createApp(store);
  server.listen(port, host, () => console.log('Transit Atlas is ready at http://' + host + ':' + server.address().port));
  const stop = () => server.close(() => { store.close(); process.exit(0); });
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
