import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { listSql, insertSql, pruneSql, fromRow, parameters } from './queries.mjs';

export function openStore(directory) {
  mkdirSync(directory, { recursive: true });
  const db = new DatabaseSync(join(directory, 'experiments.sqlite'));
  db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  db.exec(readFileSync(new URL('../database/schema.sql', import.meta.url), 'utf8'));
  const list = db.prepare(listSql);
  const insert = db.prepare(insertSql);
  const prune = db.prepare(pruneSql);
  return {
    list(owner) { return list.all(owner).map(fromRow); },
    save(owner, run) {
      db.exec('BEGIN IMMEDIATE');
      try {
        insert.run(...parameters(owner, run));
        prune.run(owner, owner);
        db.exec('COMMIT');
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
    close() { db.close(); }
  };
}
