import { SAMPLES, classify, evaluate } from '../lib/model.mjs';

const MAX_BYTES = 256 * 1024;
const COOKIE = 'transit_atlas_lab';

class RequestError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function json(body, status = 200, headers = {}) {
  return Response.json(body, {
    status,
    headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers }
  });
}

async function readJson(request) {
  if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') {
    throw new RequestError(415, 'Send the request as application/json.');
  }
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) {
    throw new RequestError(403, 'Use the API from the same site.');
  }
  if (Number(request.headers.get('content-length')) > MAX_BYTES) {
    throw new RequestError(413, 'The uploaded signal exceeds 256 KiB.');
  }
  const reader = request.body?.getReader();
  if (!reader) throw new RequestError(400, 'Include a JSON request body.');
  const decoder = new TextDecoder();
  let size = 0;
  let text = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > MAX_BYTES) {
      await reader.cancel();
      throw new RequestError(413, 'The uploaded signal exceeds 256 KiB.');
    }
    text += decoder.decode(value, { stream: true });
  }
  try {
    const value = JSON.parse(text + decoder.decode());
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch {
    throw new RequestError(400, 'Supply a valid JSON object.');
  }
}

async function ownerHash(token) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

function readToken(request) {
  const value = (request.headers.get('cookie') || '').split(';')
    .map(part => part.trim()).find(part => part.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  return value && /^[a-f0-9]{64}$/.test(value) ? value : null;
}

export async function handleApi(request, store) {
  const { pathname, protocol } = new URL(request.url);
  try {
    const method = request.method;
    if (pathname === '/api/samples' && method === 'GET') return json({ samples: SAMPLES });
    if (pathname === '/api/model' && method === 'GET') return json(evaluate());

    if (pathname === '/api/runs' && method === 'GET') {
      const token = readToken(request);
      return json({ runs: token ? await store.list(await ownerHash(token)) : [] });
    }
    if ((pathname === '/api/classify' || pathname === '/api/runs') && method === 'POST') {
      const body = await readJson(request);
      let result;
      try { result = classify(body.points); }
      catch (error) { throw new RequestError(422, error.message); }
      if (pathname === '/api/classify') return json(result);
      const name = typeof body.name === 'string' ? body.name.trim() : '';
      if (!name || name.length > 100) throw new RequestError(422, 'Use an experiment name of 1 to 100 characters.');
      const existing = readToken(request);
      const token = existing || Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2, '0')).join('');
      const run = {
        id: crypto.randomUUID(), name, createdAt: new Date().toISOString(),
        points: body.points.map(({ phase, flux }) => ({ phase, flux })).sort((a, b) => a.phase - b.phase),
        result
      };
      await store.save(await ownerHash(token), run);
      const secure = protocol === 'https:' ? '; Secure' : '';
      return json({ run }, 201, { 'Set-Cookie': COOKIE + '=' + token + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000' + secure });
    }
    const routes = { '/api/samples': 'GET', '/api/model': 'GET', '/api/classify': 'POST', '/api/runs': 'GET, POST' };
    if (routes[pathname]) return json({ error: 'Unsupported request method.' }, 405, { Allow: routes[pathname] });
    return json({ error: 'Unknown API endpoint.' }, 404);
  } catch (error) {
    if (error instanceof RequestError) return json({ error: error.message }, error.status);
    console.error('Transit Atlas API failure', error.name, error.message);
    return json({ error: 'The experiment service is unavailable. Please try again.' }, 503);
  }
}
